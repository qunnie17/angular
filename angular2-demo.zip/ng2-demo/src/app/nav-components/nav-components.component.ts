import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nav-components',
  templateUrl: './nav-components.component.html',
  styleUrls: ['./nav-components.component.css']
})
export class NavComponentsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
