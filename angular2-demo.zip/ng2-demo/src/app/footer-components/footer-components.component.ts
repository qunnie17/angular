import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-footer-components',
  templateUrl: './footer-components.component.html',
  styleUrls: ['./footer-components.component.css']
})
export class FooterComponentsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
