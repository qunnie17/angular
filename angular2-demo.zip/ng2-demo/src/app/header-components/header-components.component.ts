import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header-components',
  templateUrl: './header-components.component.html',
  styleUrls: ['./header-components.component.css']
})
export class HeaderComponentsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
