/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { ValidateDirective } from './validate.directive';

describe('ValidateDirective', () => {
  it('should create an instance', () => {
    const directive = new ValidateDirective();
    expect(directive).toBeTruthy();
  });
});
