## angular2-seed-cn

这是Angular2种子工程的中文版，原版工程在这里https://github.com/mgechev/angular2-seed

原工程是《迈向Angular2》一书中多次提到的种子项目，但是那个种子项目实在太简陋了，于是我自己扩展了一些内容，希望能给大家更好地参考。

## 用法

    npm install
    npm start

然后在你的浏览器中访问http://localhost:3000

## 注意

这个项目是用webpack做编译的，如果你还不熟悉它，请先去看看这个工具的基本用法，主要是配置文件webpack.config里面各种配置项的含义。