import {Directive, Component, ElementRef, HostListener} from '@angular/core';
import construct = core.Reflect.construct;

@Component({
  selector: 'home',
  styleUrls: ['./home.css'],
  templateUrl: './home.html'
})
export class Home {
	welcome: string;
	items: string[];
	constructor() {
		this.welcome = "欢迎访问！";
		this.items = ["百度", "google", "淘宝", "搜狐", "豆瓣"];
	}
	addItem(newItemName: string) {
		if (!newItemName) {
			alert("请输入网站名称");
			return;
		}
		this.items.push(newItemName);
	}
}
@Component({
  selector: 'home',
  styleUrls: ['./home.css'],
  templateUrl: './home.html'
})
export class addNew {
  constructor(
    public userName: string,
    public userEmail: string,
  ) {  }
  model=new addNew("","");
  add=false;
  submitted=false;
  addMessage(){
    this.add=true;
  }
  onSubmit(){
    this.submitted=true;
  }
  get submittedMessage(){return JSON.stringify(addNew);}
}

